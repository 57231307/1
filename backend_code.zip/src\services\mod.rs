pub mod auth_service;
pub mod init_service;
pub mod user_service;
pub mod role_permission_service;
pub mod product_service;
pub mod product_category_service;
pub mod warehouse_service;
pub mod department_service;
pub mod dashboard_service;
pub mod finance_payment_service;
pub mod finance_invoice_service;
pub mod sales_service;
pub mod inventory_stock_service;
pub mod inventory_transfer_service;
pub mod inventory_count_service;
pub mod inventory_adjustment_service;
pub mod inventory_reservation_service;
pub mod batch_service;
pub mod customer_service;
pub mod five_dimension_query_service;
pub mod assist_accounting_service;
pub mod business_trace_service;
// 供应商管理模块
pub mod supplier_service;
pub mod supplier_evaluation_service;
// 采购管理模块
pub mod purchase_order_service;
pub mod purchase_receipt_service;
pub mod purchase_return_service;
pub mod purchase_inspection_service;
// 应付管理模块
pub mod ap_invoice_service;
pub mod ap_payment_request_service;
pub mod ap_payment_service;
pub mod ap_verification_service;
pub mod ap_reconciliation_service;
pub mod ap_report_service;
// 应收管理模块
pub mod ar_invoice_service;
// 总账管理模块
pub mod account_subject_service;
pub mod voucher_service;
// 成本管理模块
pub mod cost_collection_service;
// P1 模块
pub mod fixed_asset_service;
pub mod purchase_contract_service;
pub mod sales_contract_service;
pub mod customer_credit_service;
pub mod fund_management_service;
pub mod budget_management_service;
pub mod quality_standard_service;
// P2 模块
pub mod financial_analysis_service;
pub mod purchase_price_service;
pub mod sales_price_service;
pub mod sales_analysis_service;
pub mod quality_inspection_service;
