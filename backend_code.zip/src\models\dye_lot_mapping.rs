impl ActiveModelBehavior for ActiveModel {}
